Today is 2019-07-16
