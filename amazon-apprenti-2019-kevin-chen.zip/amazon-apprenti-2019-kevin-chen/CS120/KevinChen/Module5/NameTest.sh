#! /bin/bash
printf "%s\n" "$name"
