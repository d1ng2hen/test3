#! /bin/bash

printf "%s\n" "Hello World!"
